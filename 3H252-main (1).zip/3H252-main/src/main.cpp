#include <iostream>
#include <Foco.hpp>

using namespace std;

int main(int argc, char const *argv[])
{
    Foco f;
    cout<<"hola mundo"<<endl;
    return 0;
}