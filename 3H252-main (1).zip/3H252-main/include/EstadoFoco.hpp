#pragma once

typedef bool EstadoFoco;